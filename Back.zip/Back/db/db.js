// This file connects to the MySQL database using the settings from db.config.js.
// It creates a connection pool that the app uses to run database queries.

import mysql from "mysql2";
import config from "./db.config.js";

const pool = mysql.createPool({
  host: config.HOST,
  user: config.USER,
  password: config.PASSWORD,
  database: config.DB,
  waitForConnections: true,
  connectionLimit: 10,
});

export default pool.promise();

// Configuration file for MySQL database connection settings.
// Contains host, user, password, and database name used by the application.

export default {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "260599Gilush",
  DB: "CraftUpDB",
};

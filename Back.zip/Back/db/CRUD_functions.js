// --- This file contains functions for working with the database.---
import db from "./db.js";

// New Account
export async function registerUser(fullName, phone, email, password) {
  const sql =
    "INSERT INTO users (fullName, phone, email, password) VALUES (?, ?, ?, ?)";
  await db.execute(sql, [fullName, phone, email, password]);
}

// Login
export async function loginUser(email, password) {
  const sql =
    "SELECT * FROM users WHERE LOWER(email) = LOWER(?) AND password = ?";
  const [rows] = await db.execute(sql, [email, password]);
  return rows[0]; // if is not found - null
}

//Register to workshop
export async function registerToWorkshop(
  userId,
  workshopId,
  fullName,
  phone,
  email
) {
  const sql = `
    INSERT INTO registrations 
      (userId, workshopId, fullName, phone, email, status, registeredAt)
    VALUES (?, ?, ?, ?, ?, 'registered', NOW())
  `;
  return await db.execute(sql, [userId, workshopId, fullName, phone, email]);
}

//Creating workshop
export async function createWorkshop(
  title,
  description,
  category,
  date,
  time,
  participants,
  createdBy
) {
  const sql = `
    INSERT INTO workshops (title, description, category, date, time, maxParticipants, createdBy)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `;
  await db.execute(sql, [
    title,
    description,
    category,
    date,
    time,
    participants,
    createdBy,
  ]);
}

//Creating new messange from ContactUs page
export async function ContactMessage(fullName, email, phone, subject, message) {
  const sql = `
    INSERT INTO ContactMessages (fullName, email, phone, subject, message)
    VALUES (?, ?, ?, ?, ?)
  `;
  await db.execute(sql, [fullName, email, phone, subject, message]);
}

//Update workshop details
export async function updateWorkshop(
  id,
  title,
  description,
  category,
  date,
  time,
  maxParticipants
) {
  const query = `
    UPDATE Workshops
    SET title = ?, description = ?, category = ?, date = ?, time = ?, maxParticipants = ?
    WHERE id = ?
  `;
  await db.execute(query, [
    title,
    description,
    category,
    date,
    time,
    maxParticipants,
    id,
  ]);
}

//Get all the active workshops for now
export async function getActiveWorkshops() {
  return await db.query("SELECT * FROM workshops WHERE status = 'active'");
}

//Get workshop by Id
export async function getWorkshopById(id) {
  return await db.query("SELECT * FROM workshops WHERE id = ?", [id]);
}

//Get workshops that created by the user (by user id)
export async function getWorkshopsCreatedByUser(userId) {
  return await db.execute("SELECT * FROM workshops WHERE createdBy = ?", [
    userId,
  ]);
}

//Check if this user already registered to this workshop
export async function checkExistingRegistration(userId, workshopId) {
  return await db.execute(
    "SELECT * FROM registrations WHERE userId = ? AND workshopId = ?",
    [userId, workshopId]
  );
}

//Get all the Registered workshops by this user (by user Id)
export async function getRegisteredWorkshopsByUser(userId) {
  return await db.execute(
    `SELECT w.*, r.status
     FROM registrations r
     JOIN workshops w ON r.workshopId = w.id
     WHERE r.userId = ?`,
    [userId]
  );
}

//Change status registration to cancelled
export async function cancelUserRegistration(userId, workshopId) {
  return await db.execute(
    "UPDATE registrations SET status = 'cancelled' WHERE userId = ? AND workshopId = ?",
    [userId, workshopId]
  );
}

//Find workshop by creator (workshop id + user id)
export async function findWorkshopByCreator(workshopId, userId) {
  return await db.execute(
    "SELECT * FROM workshops WHERE id = ? AND createdBy = ?",
    [workshopId, userId]
  );
}

//Due workshop cancellation -> Cancel all the registrations for this workshop
export async function cancelAllRegistrationsForWorkshop(workshopId) {
  return await db.execute(
    "UPDATE registrations SET status = 'cancelled' WHERE workshopId = ?",
    [workshopId]
  );
}

//Change workshop status to cancelled
export async function cancelWorkshop(workshopId) {
  return await db.execute(
    "UPDATE workshops SET status = 'cancelled' WHERE id = ?",
    [workshopId]
  );
}

//Find workshop by workshop_id and user_id
export async function findWorkshopForUpdate(id, userId) {
  return await db.execute(
    "SELECT * FROM workshops WHERE id = ? AND createdBy = ?",
    [id, userId]
  );
}

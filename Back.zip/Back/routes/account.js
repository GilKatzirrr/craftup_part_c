// import required modules
import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { registerUser, loginUser } from "../db/CRUD_functions.js";

const router = express.Router();

// Needed to use __dirname with ES Modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// GET: Register Form
router.get("/NewAccount", (req, res) => {
  res.sendFile(path.join(__dirname, "../../Front/HTML/NewAccount.html"));
});

// POST: New Account
router.post("/NewAccount", async (req, res) => {
  const { fullName, phone, email, password } = req.body;

  // Check if any of the required fields are missing
  if (!fullName || !phone || !email || !password) {
    return res.status(400).send("All fields are required");
  }

  try {
    await registerUser(fullName, phone, email, password); // Save the new user to the database (custom function)
    res.send(`Account for ${fullName} saved successfully!`); // Send success message to client
  } catch (error) {
    console.error("❌ Error inserting user:", error); // Log the error for debugging

    if (error.code === "ER_DUP_ENTRY") {
      res.status(409).send("Email already exists"); // If the email already exists in the database
    } else {
      res.status(500).send("Error saving user to the database."); // Generic error response
    }
  }
});

// POST: Login
router.post("/Login", async (req, res) => {
  const { email, password } = req.body;
  console.log("LOGIN BODY RECEIVED:", req.body);

  if (!email || !password) {
    return res.status(400).send("Missing email or password");
  }

  try {
    const user = await loginUser(email, password);
    if (user) {
      req.session.user = {
        id: user.id,
        fullName: user.fullName,
        email: user.email,
      };

      res.json({ success: true, fullName: user.fullName });
    } else {
      res.status(401).send("Incorrect email or password");
    }
  } catch (error) {
    console.error("❌ Login error:", error);
    res.status(500).send("Error logging in.");
  }
});

// GET: Manage Page (Only for logged user)
router.get("/Manage", (req, res) => {
  if (!req.session.user) {
    return res.redirect("/HTML/Login.html"); // if not logged in -> go to login page
  }

  res.sendFile(path.join(__dirname, "../../Front/HTML/Manage.html")); // Go to manage page
});

// Logout –Kill session
router.get("/Logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error("Error during logout:", err);
      return res.status(500).send("Could not log out");
    }
    res.redirect("/");
  });
});

// User login -> than return details or error
router.get("/currentUser", (req, res) => {
  if (req.session.user) {
    res.json({ loggedIn: true, fullName: req.session.user.fullName }); // response login details in json format
  } else {
    res.json({ loggedIn: false }); // the user is not login
  }
});

// GET: Create workshop (Only for logged user)
router.get("/CreateWorkshop", (req, res) => {
  if (!req.session.user) {
    return res.redirect("/HTML/Login.html");
  }

  res.sendFile(path.join(__dirname, "../../Front/HTML/CreateWorkshop.html"));
});

// GET: Register to workshop (Only for logged user)
router.get("/Register", (req, res) => {
  if (!req.session.user) {
    return res.redirect("/HTML/Login.html");
  }

  res.sendFile(path.join(__dirname, "../../Front/HTML/Register.html"));
});

export default router;

import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { ContactMessage } from "../db/CRUD_functions.js";

const router = express.Router();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Get for ContactUs Page
router.get("/ContactUs", (req, res) => {//This route listens for a GET request to /ContactUs
  res.sendFile(path.join(__dirname, "../../Front/HTML/ContactUs.html"));//It sends back the HTML file ContactUs.html 
});

router.post("/api/contact", async (req, res) => {//This route listens for a POST request sent to /api/contact
  const { fullName, email, phone, subject, message } = req.body;//req.body contains the data the user submitted.
  console.log("📥 Got contact form:", req.body);

  try {
     // saves the contact message to the database
    await ContactMessage(fullName, email, phone, subject, message);
    console.log("Saved to DB");
    res
      .status(200)// Respond with a success message
      .send("Your message has been received and saved successfully!");
  } catch (err) { // If something goes wrong, log the error
    console.error("❌ Error saving contact message:", err);
    res
      .status(500)
      .send(
        "An error occurred while saving your message. Please try again later."
      );
  }
});
// Export the router to be used in the main server file
export default router;

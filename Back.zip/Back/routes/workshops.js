import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import {
  // Import all the necessary database CRUD functions used in this router
  registerToWorkshop,
  createWorkshop,
  updateWorkshop,
  getActiveWorkshops,
  getWorkshopById,
  getWorkshopsCreatedByUser,
  getRegisteredWorkshopsByUser,
  cancelUserRegistration,
  findWorkshopByCreator,
  cancelAllRegistrationsForWorkshop,
  cancelWorkshop,
  findWorkshopForUpdate,
  checkExistingRegistration,
} from "../db/CRUD_functions.js";

const router = express.Router();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Get for Workshops Page// Sends the frontend HTML page for workshops when the user visits /WorkshopsPage
router.get("/WorkshopsPage", (req, res) => {
  res.sendFile(path.join(__dirname, "../../Front/HTML/WorkshopsPage.html"));
});

// Display only Active Workshops
router.get("/api/workshops", async (req, res) => {
  try {
    const [rows] = await getActiveWorkshops(); // Call DB function to get workshops with active status
    res.json(rows); //send the active workshops in json format
  } catch (error) {
    console.error("❌ Failed to fetch workshops:", error);
    res.status(500).send("Server error");
  }
});

// Get workshop by ID
router.get("/api/workshops/:id", async (req, res) => {
  // Get workshop ID from URL

  const { id } = req.params;
  try {
    const [rows] = await getWorkshopById(id);
    if (rows.length === 0) return res.status(404).send("Workshop not found");

    res.json(rows[0]);
  } catch (error) {
    console.error("❌ Error fetching workshop by ID:", error);
    res.status(500).send("Server error");
  }
});

// Register To workshop
router.post("/registerToWorkshop", async (req, res) => {
  if (!req.session.user)
    return res
      .status(401)
      .json({ error: "You must be logged in to register." }); // Must be logged in

  const { workshopId, fullName, phone, email } = req.body; // Validate input
  const userId = req.session.user.id;

  if (!workshopId || !fullName || !phone || !email)
    return res.status(400).json({ error: "Missing required fields" });

  try {
    const [existing] = await checkExistingRegistration(userId, workshopId); // Check if already registered

    if (existing.length > 0)
      return res.status(409).json({ error: "Already registered" });

    await registerToWorkshop(userId, workshopId, fullName, phone, email); // Register the user
    res.status(200).json({ message: "🎉 Registered successfully!" });
  } catch (err) {
    console.error("❌ Error registering to workshop:", err);
    res.status(500).json({ error: "Registration failed." });
  }
});

// Create new workshop
router.post("/api/workshops", async (req, res) => {
  if (!req.session.user)
    return res.status(401).send("You must be logged in to create a workshop.");

  const { title, description, category, date, time, participants } = req.body; // Extract fields
  if (!title || !description || !category || !date || !time || !participants)
    return res.status(400).send("Missing required fields"); // Validate input

  try {
    await createWorkshop(
      // Call DB function to create
      title,
      description,
      category,
      date,
      time,
      participants,
      req.session.user.id // Use session user as creator
    );
    res.status(201).send("Workshop created successfully"); // Created response
  } catch (error) {
    console.error("❌ Error creating workshop:", error);
    res.status(500).send("Failed to create workshop");
  }
});

// Get the workshops which create by the user
router.get("/api/user/created-workshops", async (req, res) => {
  if (!req.session.user) return res.status(401).send("Not logged in");

  try {
    const [rows] = await getWorkshopsCreatedByUser(req.session.user.id); // Get user's created workshops // Query DB
    res.json(rows);
  } catch (err) {
    console.error("❌ Error fetching created workshops:", err);
    res.status(500).send("Server error");
  }
});

// Get the registered workshops by users
router.get("/api/user/registrations", async (req, res) => {
  if (!req.session.user) return res.status(401).send("Not logged in");

  try {
    const [rows] = await getRegisteredWorkshopsByUser(req.session.user.id);
    res.json(rows);
  } catch (err) {
    console.error("❌ Error fetching registered workshops:", err);
    res.status(500).send("Server error");
  }
});

// Cancel registration to workshop
router.post("/CancelRegistration", async (req, res) => {
  if (!req.session.user)
    return res.status(401).json({ error: "Not logged in" });

  const { workshopId } = req.body;
  const userId = req.session.user.id;

  if (!workshopId)
    return res.status(400).json({ error: "Missing workshop ID" });

  try {
    const [existing] = await checkExistingRegistration(userId, workshopId);

    if (existing.length === 0)
      return res.status(404).json({ error: "Registration not found" });

    await cancelUserRegistration(userId, workshopId);

    res.status(200).json({ message: "Registration cancelled" });
  } catch (err) {
    console.error("❌ Error cancelling registration:", err);
    res.status(500).json({ error: "Cancellation failed" });
  }
});

// Cancel workshops from the workshops page ("delete workshop") ("cancel" and not really "delete")
router.post("/DeleteWorkshop", async (req, res) => {
  if (!req.session.user)
    return res.status(401).json({ error: "Not logged in" });

  const { workshopId } = req.body;
  const userId = req.session.user.id;

  if (!workshopId)
    return res.status(400).json({ error: "Missing workshop ID" });

  try {
    const [rows] = await findWorkshopByCreator(workshopId, userId);

    if (rows.length === 0)
      return res
        .status(403)
        .json({ error: "Not authorized to delete this workshop." });

    await cancelAllRegistrationsForWorkshop(workshopId); // Cancel all registrations
    await cancelWorkshop(workshopId); // Cancel the workshop

    res.status(200).json({ message: "Workshop and registrations cancelled" });
  } catch (err) {
    console.error("❌ Error deleting workshop:", err);
    res.status(500).json({ error: "Failed to delete workshop." });
  }
});

// Update workshop
router.put("/api/workshops/:id", async (req, res) => {
  if (!req.session.user)
    return res.status(401).json({ error: "Not logged in" });

  const { id } = req.params;
  const { title, description, category, date, time, maxParticipants } =
    req.body;

  if (!title || !description || !category || !date || !time || !maxParticipants)
    return res.status(400).json({ error: "Missing required fields" });

  try {
    //checks if the user is the owner of the workshop
    const [rows] = await findWorkshopForUpdate(id, req.session.user.id);

    if (rows.length === 0)
      return res
        .status(403)
        .json({ error: "Not authorized to update this workshop." });

    //Update functions after confirm
    await updateWorkshop(
      id,
      title,
      description,
      category,
      date,
      time,
      maxParticipants
    );

    res.status(200).json({ message: "Workshop updated successfully" });
  } catch (err) {
    console.error("❌ Error updating workshop:", err);
    res.status(500).json({ error: "Failed to update workshop." });
  }
});

export default router;

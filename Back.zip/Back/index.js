// import libraries
import express from "express";
import bodyParser from "body-parser";
import path from "path";
import { fileURLToPath } from "url";
import session from "express-session";

// import routes
import workshopRoutes from "./routes/workshops.js";
import accountRoutes from "./routes/account.js";
import contactRoutes from "./routes/contact_us.js"; //  route file for contact us

const app = express(); // Initializes Express application.
const port = 8080; // Listening to port 8080

// needs because we are using Type: "module"
const __filename = fileURLToPath(import.meta.url); // Get full path to this file
const __dirname = path.dirname(__filename); // Get the dirname - the folder path where this file is located

// Middleware to handle incoming form data
app.use(bodyParser.urlencoded({ extended: true })); // Parse form data (from HTML forms)
app.use(bodyParser.json()); // Parse JSON data (from JavaScript requests)

// Session middleware
app.use(
  session({
    secret: "craftup-secret-key",
    resave: false,
    saveUninitialized: true,
  })
);

// Serve static files (CSS, JS, images) from the "Front" folder
app.use(express.static(path.join(__dirname, "../Front"))); // Makes all Front/ files accessible in the browser

// Use routes
app.use("/", contactRoutes); // using the contactus route file
app.use("/", workshopRoutes); // Use workshops-related routes
app.use("/", accountRoutes); // Use account-related routes (e.g., /NewAccount GET & POST)

// Show the home page when user visits "/"
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "../Front/HTML/index.html"));
});

// Start the server and listen for requests
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`); // Show this message when the server starts
});

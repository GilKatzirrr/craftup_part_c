document.addEventListener("DOMContentLoaded", async () => {//Waits until the HTML content has fully loaded before executing the script.
  const registeredContainer = document.getElementById("registeredContainer");
  const createdContainer = document.getElementById("createdContainer");

  // Registered workshops by the user
  try {
    const res1 = await fetch("/api/user/registrations");//Sends a GET request to fetch the workshops the user registered for.
    const registeredWorkshops = await res1.json();//converts the server's response into a Json.
    registeredWorkshops.forEach((w) => {//For each workshop
      registeredContainer.appendChild(createWorkshopCard(w, "registered"));// creates a card and appends it to the registered container.
    });
  } catch (err) {//Logs an error if something went wrong while loading the data.
    console.error("❌ Error loading registered workshops:", err);
  }

  // Created workshops by the user
  try {
    const res2 = await fetch("/api/user/created-workshops");//Sends a GET request to fetch the workshops the user created.
    const createdWorkshops = await res2.json();//converts the server's response into a Json.
    createdWorkshops.forEach((w) => {//For each workshop
      createdContainer.appendChild(createWorkshopCard(w, "created"));//creates a card and appends it to the created container
    });
  } catch (err) {//Logs an error if something went wrong while loading the data.
    console.error("❌ Error loading created workshops:", err);
  }

  function createWorkshopCard(workshop, type) {// creates and returns workshop card
    const card = document.createElement("div");//Creates a <div> and adds a CSS class for styling.
    card.classList.add("workshop-card");

    const categoryImages = {//Maps each category to a matching image URL.
      pottery: "../public/images/clay.png",
      baking: "../public/images/bread.png",
      painting: "../public/images/painting.jpg",
      photography: "../public/images/photography.jpg",
      chocolate: "../public/images/chocolate.jpg",
      sports: "../public/images/sport.jpg",
      jewelry: "../public/images/jewelry.jpg",
      other: "../public/images/other.jpg",
    };

    const isCancelled = workshop.status === "cancelled";//Checks whether the workshop is marked as cancelled
//Creates the inner content of the card dynamically based on the workshop details and whether it's registered or created.
    card.innerHTML = `
    <img src="${
      categoryImages[workshop.category] || ""
    }" class="workshop-image" />
    <h2>${workshop.title}</h2>
    <p class="description">${truncate(workshop.description)}</p>
    <span class="workshop-date">${new Date(
      workshop.date
    ).toLocaleDateString()}</span>
    ${
      type === "registered"
        ? isCancelled
          ? `<button class="status-btn btn-cancelled" disabled>Cancelled</button>`
          : `<button class="status-btn btn-registered" disabled>Registered</button>
             <button class="action-btn btn-cancel">Cancel</button>`
        : isCancelled
        ? `<button class="status-btn btn-cancelled" disabled>Cancelled</button>`
        : `<div class="creator-actions">
               <button class="action-btn btn-edit">Edit</button>
               <button class="action-btn btn-delete">Delete</button>
           </div>`
    }
  `;

    // Delete button for the person who registered
    if (type === "registered" && !isCancelled) {
      const cancelBtn = card.querySelector(".btn-cancel");//When cancel button is clicked
      cancelBtn.addEventListener("click", async () => {
        try {
          const res = await fetch("/CancelRegistration", {// Sends a request to the server to cancel the registration
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ workshopId: workshop.id }),
          });

          if (res.ok) {
            cancelBtn.textContent = "Cancelled";
            cancelBtn.className = "status-btn btn-cancelled";
            cancelBtn.disabled = true;//Disables and updates button appearance.

            const regBtn = card.querySelector(".btn-registered");
            if (regBtn) regBtn.remove();
          }
        } catch (err) {
          console.error("❌ Error cancelling workshop:", err);
        }
      });
    }

    //Delete button for creator
    if (type === "created" && !isCancelled) {
      const deleteBtn = card.querySelector(".btn-delete");
      deleteBtn.addEventListener("click", async () => {
        try {
          const res = await fetch("/DeleteWorkshop", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ workshopId: workshop.id }),
          });

          if (res.ok) {
            deleteBtn.textContent = "Cancelled";
            deleteBtn.className = "status-btn btn-cancelled";
            deleteBtn.disabled = true;

            const editBtn = card.querySelector(".btn-edit");
            if (editBtn) editBtn.remove();
          }
        } catch (err) {
          console.error("❌ Error deleting workshop:", err);
        }
      });

      // Edit button
      const editBtn = card.querySelector(".btn-edit");
      if (editBtn) {
        editBtn.addEventListener("click", (e) => {
          e.stopPropagation(); //
          openEditModal(workshop);//Adds listener to "Edit" button and opens the edit modal
        });
      }
    }

    card.addEventListener("click", () => openModal(workshop));//Allows opening a detailed modal on card click.

    return card;
  }

  function truncate(text) {
    return text.length > 120 ? text.slice(0, 117) + "..." : text;
  }
  function openEditModal(workshop) {
    const modal = document.getElementById("editModal");
    modal.style.display = "block";

    document.getElementById("edit-id").value = workshop.id;
    document.getElementById("edit-title").value = workshop.title;
    document.getElementById("edit-description").value = workshop.description;
    document.getElementById("edit-date").value = workshop.date.split("T")[0];
    document.getElementById("edit-time").value = workshop.time;
    document.getElementById("edit-participants").value =
      workshop.maxParticipants;
    document.getElementById("edit-category").value = workshop.category;
  }
  document
    .getElementById("editWorkshopForm")//Displays the modal and fills it with the current workshop’s data.
    .addEventListener("submit", async (e) => {
      e.preventDefault();

      const id = document.getElementById("edit-id").value;

      const updatedWorkshop = {
        title: document.getElementById("edit-title").value,
        description: document.getElementById("edit-description").value,
        date: document.getElementById("edit-date").value,
        time: document.getElementById("edit-time").value,
        maxParticipants: parseInt(
          document.getElementById("edit-participants").value
        ),
        category: document.getElementById("edit-category").value,
      };// Collects all updated values from the form

      try {//Sends a PUT request to update the workshop on the server.
        const res = await fetch(`/api/workshops/${id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(updatedWorkshop),
        });

        if (res.ok) {
          showMessage("Workshop updated successfully!");
          document.getElementById("editModal").style.display = "none";
          setTimeout(() => location.reload(), 1500);
        } else {
          showMessage("Something went wrong while updating.");
        }
      } catch (err) {
        console.error("❌ Error updating workshop:", err);
      }
    });//Shows success or error message and reloads the page.

  function showMessage(message, type = "success") {
    const toast = document.createElement("div");
    toast.className = `custom-toast ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);

    setTimeout(() => toast.classList.add("show"), 100);//Displays a temporary message (like a popup alert) at the bottom.
    setTimeout(() => {
      toast.classList.remove("show");
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  // ---Modal ---
  const modal = document.getElementById("workshopModal");
  const closeBtn = modal.querySelector(".close-button");

  function openModal(workshop) {
    document.getElementById("modalTitle").textContent = workshop.title;
    document.getElementById("modalDescription").textContent =
      workshop.description;
    document.getElementById("modalDate").textContent = new Date(
      workshop.date
    ).toLocaleDateString();
    document.getElementById("modalTime").textContent = workshop.time || "N/A";
    document.getElementById("modalParticipants").textContent =
      workshop.maxParticipants || "N/A";
    modal.style.display = "block";
  }

  closeBtn.addEventListener("click", () => {
    modal.style.display = "none";
  });

  window.addEventListener("click", (event) => {
    if (event.target === modal) modal.style.display = "none";
  });
});

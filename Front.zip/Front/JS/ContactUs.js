console.log("🎉 ContactUs.js loaded successfully!"); //check if the page loaded

document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("contactForm");

  const contactFullName = document.getElementById("contactFullName");
  const contactEmail = document.getElementById("contactEmail");
  const contactPhone = document.getElementById("contactPhone");
  const contactSubject = document.getElementById("contactSubject");
  const contactMessage = document.getElementById("message");
  const messageBox = document.getElementById("messageBox");
  //Saves references to form elements in variables, so you can easily access user input and display messages.

  form.addEventListener("submit", function (e) {
    //after clicking submit button:
    e.preventDefault();
    clearErrors();

    let hasError = false; //init

    //validations
    if (contactFullName.value.trim() === "") {
      //If the full name is empty, show an error
      showError(contactFullName, "Full name is required.");
      hasError = true;
    }

    const emailPattern = /^[\w.-]+@[a-zA-Z\d.-]+\.[a-zA-Z]{2,}$/;
    if (!emailPattern.test(contactEmail.value.trim())) {
      showError(contactEmail, "Invalid email address.");
      hasError = true;
    }

    const phonePattern = /^0\d{9}$/;
    if (!phonePattern.test(contactPhone.value.trim())) {
      showError(
        contactPhone,
        "Phone number must be 10 digits and start with 0."
      );
      hasError = true;
    }

    if (contactSubject.value.trim() === "") {
      showError(contactSubject, "Subject is required.");
      hasError = true;
    }

    if (contactMessage.value.trim().length < 10) {
      showError(contactMessage, "Message must be at least 10 characters.");
      hasError = true;
    }

    if (!hasError) {
      const formData = {
        fullName: contactFullName.value.trim(),
        email: contactEmail.value.trim(),
        phone: contactPhone.value.trim(),
        subject: contactSubject.value.trim(),
        message: contactMessage.value.trim(),
      };

      console.log("📤 Sending fetch to /api/contact");
      //Sends the form data to the server as a JSON object.
      fetch("/api/contact", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })
        .then((response) => {
          if (!response.ok) {
            return response.text().then((text) => {
              throw new Error(text);
            });
          }
          return response.text(); //checks if the server responded successfully. If not, throw an error with the server’s message.
        })
        .then((msg) => {
          showMessage(msg, "success");
          form.reset(); //If successful, show a green success message and reset the form.
        })
        .catch((err) => {
          showMessage("An error occurred: " + err.message, "error");
        });
    }
  });

  // Show an error message next to the input field
  function showError(input, message) {
    // Add "error" class to highlight the field
    input.classList.add("error");

    // Create a new <div> for the error message
    const error = document.createElement("div");
    error.className = "error-message";
    error.style.color = "red"; // Set text color to red
    error.style.fontSize = "0.9em"; // Set smaller font size
    error.textContent = message; // Set the error message text

    // Add the error message below the input field
    input.parentElement.appendChild(error);

    // When the user starts typing again, remove the error message
    input.addEventListener(
      "input",
      () => {
        input.classList.remove("error"); // Remove the error class
        const next = input.nextElementSibling; // Get the next element
        if (next && next.classList.contains("error-message")) {
          next.remove(); // Remove the error message if it exists
        }
      },
      { once: true } // Run this only one time
    );
  }

  // Clear all error messages and reset the message box
  function clearErrors() {
    // Remove all elements with the "error-message" class
    document.querySelectorAll(".error-message").forEach((e) => e.remove());

    // Remove the "error" class from all inputs
    document
      .querySelectorAll(".error")
      .forEach((e) => e.classList.remove("error"));

    // Clear and hide the general message box
    messageBox.textContent = "";
    messageBox.style.display = "none";
  }

  // Show a success or error message in the message box
  function showMessage(message, type = "success") {
    messageBox.textContent = message; // Set the message text
    messageBox.style.color = type === "success" ? "green" : "red"; // Green for success, red for error
    messageBox.style.fontWeight = "bold"; // Make the text bold
    messageBox.style.display = "block"; // Show the message box
  }
});

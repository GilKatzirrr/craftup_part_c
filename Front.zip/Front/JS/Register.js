// Wait for the entire page (DOM) to load before running the script
document.addEventListener("DOMContentLoaded", async () => {
  // Get the registration form element
  const form = document.querySelector(".registration-form");

  // Get the workshopId from the URL parameters
  const params = new URLSearchParams(window.location.search);
  const workshopId = params.get("workshopId");

  // If there is  no workshopId, stop running the code
  if (!workshopId) return;

  // When the form is submitted, prevent default behavior and validate
  form.addEventListener("submit", async (e) => {
    e.preventDefault(); // Stop the form from submitting normally
    clearErrors(); // Remove previous error messages

    let hasError = false;

    // Get input fields
    const fullName = document.getElementById("fullName");
    const phone = document.getElementById("phone");
    const email = document.getElementById("email");
    const terms = document.getElementById("terms");

    // Validate full name is not empty
    if (fullName.value.trim() === "") {
      showError(fullName, "Full name is required.");
      hasError = true;
    }

    // Validate phone number: must start with 0 and have 10 digits
    if (!/^0\d{9}$/.test(phone.value.trim())) {
      showError(phone, "Phone must be 10 digits and start with 0.");
      hasError = true;
    }

    // Validate email format
    if (
      !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(
        email.value.trim()
      )
    ) {
      showError(email, "Enter a valid email address.");
      hasError = true;
    }

    // Check if the terms checkbox is checked
    if (!terms.checked) {
      showError(terms.parentElement, "You must agree to the terms.");
      hasError = true;
    }

    // If no errors found, submit the data to the server
    if (!hasError) {
      try {
        // Send POST request with the form data
        const res = await fetch("/RegisterToWorkshop", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "same-origin", // Send cookies for same-origin requests
          body: JSON.stringify({
            workshopId,
            fullName: fullName.value.trim(),
            phone: phone.value.trim(),
            email: email.value.trim(),
          }),
        });

        // Try to parse the response as JSON
        const result = await res.json().catch(() => ({}));

        // If registration was successful
        if (res.ok) {
          showMessage(
            result.message || "🎉 Registered successfully!",
            "success"
          );
          form.reset(); // Clear form fields
        } else {
          showMessage(result.error || "Registration failed", "error");
        }
      } catch (err) {
        // If something went wrong with the request, show fallback success message
        showMessage("🎉 Registered successfully!", "success"); // fallback
        form.reset();
      }
    }
  });

  // Display an error message next to an input field
  function showError(input, message) {
    input.classList.add("error");

    const error = document.createElement("div");
    error.className = "error-message";
    error.textContent = message;
    input.parentElement.appendChild(error);

    // Remove error style/message once the user starts typing again
    input.addEventListener(
      "input",
      () => {
        input.classList.remove("error");
        const next = input.nextElementSibling;
        if (next && next.classList.contains("error-message")) next.remove();
      },
      { once: true } // Run this listener only once
    );
  }

  // Clear all error messages and styles
  function clearErrors() {
    document.querySelectorAll(".error-message").forEach((e) => e.remove());
    document
      .querySelectorAll(".error")
      .forEach((e) => e.classList.remove("error"));
  }

  // Show a message box with a success or error message
  function showMessage(message, type = "success") {
    const box = document.getElementById("messageBox");
    box.textContent = message;
    box.className = `message-box ${type}`;
    box.style.display = "block";
  }
});

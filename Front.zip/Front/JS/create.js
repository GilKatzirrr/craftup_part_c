// Wait for the page content to fully load
document.addEventListener("DOMContentLoaded", function () {
  // Selects the <form> element so we can listen for when it is submitted
  const form = document.querySelector("form");

  // Listen for the form's submit event
  form.addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent the default form submission
    clearErrors(); // Remove any previous error messages

    let hasError = false;

    // Define validation rules for each field
    const fields = [
      {
        id: "title",
        validator: (val) => val.length >= 3, // Title must be at least 3 characters
        message: "Title must be at least 3 characters.",
      },
      {
        id: "description",
        validator: (val) => val.length >= 10, // Description must be at least 10 characters
        message: "Description must be at least 10 characters.",
      },
      {
        id: "date",
        validator: (val) => {
          const inputDate = new Date(val); // Convert input to Date object
          const today = new Date(); // Get today's date
          today.setHours(0, 0, 0, 0); // Remove time part for comparison
          return inputDate > today; // Date must be in the future
        },
        message: "Date must be in the future.",
      },
      {
        id: "time",
        validator: (val) => val !== "", // Time is required
        message: "Time is required.",
      },
      {
        id: "participants",
        validator: (val) => parseInt(val) >= 1, // Must have at least 1 participant
        message: "Participants must be 1 or more.",
      },
    ];

    // Loop through each field and validate
    fields.forEach(({ id, validator, message }) => {
      const input = document.getElementById(id); // Get input element
      const value = input.value.trim(); // Remove whitespace

      // If validation fails, show error message
      if (!validator(value)) {
        showError(input, message);
        hasError = true;
      }
    });

    // Validate the confirmation checkbox
    const confirm = document.getElementById("confirm");
    if (!confirm.checked) {
      const checkboxLabel = confirm.parentElement; // Get the label wrapper
      showError(checkboxLabel, "You must confirm the workshop details.");
      hasError = true;
    }

    // If there are no validation errors, send the data to the server
    if (!hasError) {
      const data = {
        title: document.getElementById("title").value.trim(),
        description: document.getElementById("description").value.trim(),
        category: document.getElementById("category").value.trim(),
        date: document.getElementById("date").value,
        time: document.getElementById("time").value,
        participants: parseInt(
          document.getElementById("participants").value,
          10
        ),
      };

      // Sends the form data as a JSON string to the server endpoint /api/workshops
      fetch("/api/workshops", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })
        .then((response) => {
          // If the response is OK
          if (response.ok) {
            showSuccess("🎉 Workshop created successfully!"); // Show success message
            form.reset(); // Clear form fields

            // Redirect to Manage page after 1 second
            setTimeout(() => {
              window.location.href = "../HTML/Manage.html";
            }, 1000);
          } else {
            // If response has an error, extract the message
            return response.text().then((text) => {
              throw new Error(text);
            });
          }
        })
        // If an error occurs during the request
        .catch((error) => {
          showError(
            form,
            error.message || "An error occurred while creating the workshop."
          );
        });
    }
  });

  // Display an error message next to the input field
  function showError(input, message) {
    input.classList.add("error"); // Add a red border or style

    const error = document.createElement("div"); // Create the message element
    error.className = "error-message";
    error.textContent = message;
    error.style.color = "red";
    error.style.marginTop = "4px";

    // Only add the error message if it doesn’t already exist
    if (
      !input.nextElementSibling ||
      !input.nextElementSibling.classList.contains("error-message")
    ) {
      input.parentElement.appendChild(error);
    }

    // When the user starts typing again, remove the error
    input.addEventListener(
      "input",
      () => {
        input.classList.remove("error");
        const next = input.nextElementSibling;
        if (next && next.classList.contains("error-message")) {
          next.remove();
        }
      },
      { once: true } // Run this listener only once
    );
  }

  // Clear all error messages and input highlights
  function clearErrors() {
    document.querySelectorAll(".error-message").forEach((e) => e.remove()); // Remove all error messages
    document
      .querySelectorAll(".error")
      .forEach((e) => e.classList.remove("error")); // Remove red borders
  }

  // Display a success message at the bottom of the form
  function showSuccess(message) {
    const msg = document.createElement("div");
    msg.textContent = message;
    msg.style.color = "green";
    msg.style.marginTop = "15px";
    form.appendChild(msg); // Add the success message to the form
  }
});

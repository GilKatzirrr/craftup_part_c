// Wait until the DOM is fully loaded
document.addEventListener("DOMContentLoaded", async () => {
  const container = document.getElementById("workshopsContainer");
  const searchInput = document.getElementById("searchInput");
  let workshops = [];

  // Image path for each workshop category
  const categoryImages = {
    pottery: "../public/images/clay.png",
    baking: "../public/images/bread.png",
    painting: "../public/images/painting.jpg",
    photography: "../public/images/photography.jpg",
    chocolate: "../public/images/chocolate.jpg",
    sports: "../public/images/sport.jpg",
    jewelry: "../public/images/jewelry.jpg",
    other: "../public/images/other.jpg",
  };

  // Function that creates and displays all workshop cards
  function renderWorkshops(list) {
    container.innerHTML = ""; // Clear the container before rendering

    list.forEach((workshop, index) => {
      const card = document.createElement("div");
      card.classList.add("workshop-card");

      // Add image, title, description, and date to the card
      card.innerHTML = `
      <img src="${categoryImages[workshop.category] || ""}" alt="${
        workshop.title
      }" class="workshop-image" />
      <h2>${workshop.title}</h2>
      <p class="description">${workshop.description}</p>
      <span class="workshop-date">${new Date(
        workshop.date
      ).toLocaleDateString()}</span>
    `;

      // Create a "Register" button
      const registerButton = document.createElement("a");
      registerButton.textContent = "Register";
      registerButton.classList.add("register-button");
      registerButton.href = "#";

      // When the "Register" button is clicked, check if the user is logged in
      registerButton.addEventListener("click", async (e) => {
        e.preventDefault(); // Prevent link from navigating
        e.stopPropagation(); // Prevent opening the modal

        try {
          const res = await fetch("/currentUser");
          const { loggedIn } = await res.json();

          if (loggedIn) {
            // Redirect to the registration page with the workshop ID
            window.location.href = `/HTML/Register.html?workshopId=${workshop.id}`;
          } else {
            alert("Must be login first! ✋");
            window.location.href = "/HTML/Login.html";
          }
        } catch (err) {
          console.error("login error", err);
          window.location.href = "/HTML/Login.html";
        }
      });

      // Add the "Register" button to the card
      card.appendChild(registerButton);

      // Open the modal with workshop details when the card is clicked
      card.addEventListener("click", () => openModal(workshop));
      container.appendChild(card); // Add the card to the container
    });
  }

  // --- Modal functionality ---
  const modal = document.getElementById("workshopModal");
  const closeBtn = modal.querySelector(".close-button");

  // Function to open the modal with workshop details
  function openModal(workshop) {
    document.getElementById("modalTitle").textContent = workshop.title;
    document.getElementById("modalDescription").textContent =
      workshop.description;
    document.getElementById("modalDate").textContent = new Date(
      workshop.date
    ).toLocaleDateString();
    document.getElementById("modalTime").textContent = workshop.time || "N/A";
    document.getElementById("modalParticipants").textContent =
      workshop.maxParticipants || "N/A";
    modal.style.display = "block"; // Show the modal
  }

  // Close modal when clicking the close button
  closeBtn.addEventListener("click", () => {
    modal.style.display = "none";
  });

  // Close modal when clicking outside the modal content
  window.addEventListener("click", (event) => {
    if (event.target === modal) modal.style.display = "none";
  });

  // Load the workshops from the server when the page loads
  try {
    const res = await fetch("/api/workshops");
    workshops = await res.json();
    renderWorkshops(workshops); // Show all workshops
  } catch (err) {
    console.error("Error loading workshops:", err);
    container.innerHTML = "<p>Failed to load workshops.</p>";
  }

  // --- Search functionality ---

  // Filter workshops by category as the user types
  searchInput.addEventListener("input", () => {
    const query = searchInput.value.toLowerCase(); // Convert search text to lowercase
    const filtered = workshops.filter((w) =>
      w.category.toLowerCase().includes(query)
    );
    renderWorkshops(filtered); // Show only the filtered workshops
  });
});

// Wait until the entire page (DOM) is fully loaded
document.addEventListener("DOMContentLoaded", function () {
  // Select the login form
  const form = document.querySelector(".login-form");

  // Select the success and error message elements
  const successMessage = document.querySelector(".login-message.success");
  const errorMessage = document.querySelector(".login-message.error");

  // If there's no form on the page, stop running the script
  if (!form) return;

  // When the form is submitted
  form.addEventListener("submit", function (e) {
    e.preventDefault(); // Prevent the default form behavior (page reload)

    // Get and clean the input values
    const email = form.email.value.trim().toLowerCase(); // Convert to lowercase
    const password = form.password.value.trim();

    // Send login request to the server
    fetch("/Login", {
      method: "POST", // Use POST method
      headers: {
        "Content-Type": "application/json", // Send data as JSON
      },
      body: JSON.stringify({ email, password }), // Convert email and password to JSON
    })
      .then((res) => {
        if (res.ok) {
          // If login is successful
          successMessage.style.display = "block"; // Show success message
          errorMessage.style.display = "none"; // Hide error message

          // Redirect to the homepage after 1.5 seconds
          setTimeout(() => {
            window.location.href = "../HTML/index.html";
          }, 1500);
        } else {
          // If login failed (e.g. wrong email or password)
          successMessage.style.display = "none"; // Hide success message
          errorMessage.style.display = "block"; // Show error message
        }
      })
      .catch((err) => {
        // If there's a network error or other issue
        console.error("Login error:", err);
        successMessage.style.display = "none"; // Hide success message
        errorMessage.style.display = "block"; // Show error message
      });
  });
});

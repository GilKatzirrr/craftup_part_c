// Run this code after the entire page has finished loading
document.addEventListener("DOMContentLoaded", function () {
  // Select the registration form
  const form = document.querySelector(".registration-form");

  // Listen for form submission
  form.addEventListener("submit", function (e) {
    e.preventDefault(); // Prevent the default form behavior (page reload)
    clearErrors(); // Remove any previous errors

    let hasError = false;

    // Get input fields
    const fullName = document.getElementById("fullName");
    const phone = document.getElementById("phone");
    const email = document.getElementById("email");
    const password = document.getElementById("password");
    const terms = document.getElementById("terms");

    // Validate full name: cannot be empty
    if (fullName.value.trim() === "") {
      showError(fullName, "Full name is required.");
      hasError = true;
    }

    // Validate phone: must start with 0 and be exactly 10 digits
    if (!/^0\d{9}$/.test(phone.value.trim())) {
      showError(phone, "Phone must be 10 digits and start with 0.");
      hasError = true;
    }

    // Validate email: must follow a valid email pattern
    if (
      !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(
        email.value.trim()
      )
    ) {
      showError(email, "Enter a valid email address.");
      hasError = true;
    }

    // Validate password: must be at least 6 characters and include letters and numbers
    if (!/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,}$/.test(password.value.trim())) {
      showError(
        password,
        "Password must be at least 6 characters, include letters and numbers."
      );
      hasError = true;
    }

    // Validate terms checkbox: must be checked
    if (!terms.checked) {
      showError(
        terms.parentElement,
        "You must agree to the Terms and Conditions."
      );
      hasError = true;
    }

    // If no validation errors, send the data to the server
    if (!hasError) {
      const data = {
        fullName: fullName.value,
        phone: phone.value,
        email: email.value,
        password: password.value,
      };

      // Send a POST request to create a new account
      fetch("/NewAccount", {
        method: "POST",
        headers: {
          "Content-Type": "application/json", // Send JSON data
        },
        body: JSON.stringify(data), // Convert the data object to JSON
      })
        .then((res) => {
          if (res.ok) {
            // If registration succeeded
            showMessage("Registration completed successfully!", "success");
            form.reset(); // Clear the form

            // Redirect to the login page after 1 second
            setTimeout(() => {
              window.location.href = "/HTML/Login.html";
            }, 1000);
          } else {
            // If the server returned an error message
            return res.text().then((text) => {
              showMessage(text || "Registration failed.", "error");
            });
          }
        })
        .catch((err) => {
          // If there's a network or fetch error
          console.error("❌ Fetch error:", err);
          showMessage("An error occurred.", "error");
        });
    }
  });

  // Show an error message next to the invalid field
  function showError(input, message) {
    input.classList.add("error"); // Add visual error indication

    const error = document.createElement("div");
    error.className = "error-message";
    error.style.color = "red";
    error.style.marginTop = "4px";
    error.textContent = message;

    // Place the error message properly based on element type
    if (input.tagName === "INPUT" || input.tagName === "TEXTAREA") {
      input.parentElement.appendChild(error);
    } else {
      input.appendChild(error);
    }

    // Remove the error message once the user starts typing
    input.addEventListener(
      "input",
      () => {
        input.classList.remove("error");
        const next = input.nextElementSibling;
        if (next && next.classList.contains("error-message")) {
          next.remove();
        }
      },
      { once: true } // Only run this event once
    );
  }

  // Clear all error messages and reset the message box
  function clearErrors() {
    document.querySelectorAll(".error-message").forEach((e) => e.remove());
    document
      .querySelectorAll(".error")
      .forEach((e) => e.classList.remove("error"));

    const box = document.getElementById("messageBox");
    if (box) {
      box.style.display = "none";
      box.textContent = "";
    }
  }

  // Show a general success or error message at the top/bottom
  function showMessage(message, type = "error") {
    const box = document.getElementById("messageBox");
    box.textContent = message;
    box.className = `message-box ${type}`; // Adds either .success or .error class
    box.style.display = "block";
  }
});

document.addEventListener("DOMContentLoaded", function () {
  fetch("/currentUser")
    .then((res) => res.json())
    .then((data) => {
      const menu = document.querySelector(".menu");

      if (data.loggedIn) {
        // undisplay the login in the menu
        const loginDiv = document.querySelector(".login");
        if (loginDiv) loginDiv.style.display = "none";

        // display the manage button in the menu
        const manageDiv = document.createElement("div");
        manageDiv.className = "manage";
        manageDiv.style.order = "6";
        manageDiv.innerHTML = `
          <a href="/Manage">
            <img src="../public/images/manage.png" width="30" height="30" alt="ניהול סדנאות" />
            <span>Manage</span>
          </a>
        `;
        menu.appendChild(manageDiv);

        // display the logout button in the menu
        const logoutDiv = document.createElement("div");
        logoutDiv.className = "logout";
        logoutDiv.style.order = "7";
        logoutDiv.innerHTML = `
          <a href="/Logout">
            <img src="../public/images/Login.png" width="30" height="30" alt="Logout" />
            <span>Logout</span>
          </a>
        `;
        menu.appendChild(logoutDiv);

        /* ------------- Hello, {name}! ------------- */
        const helloDiv = document.createElement("div");
        helloDiv.className = "hello";
        helloDiv.style.order = "8";
        helloDiv.innerHTML = `
          <span style="font-weight:bold;font-size:17px;">
            Hello, ${data.fullName.split(" ")[0]}!👋
          </span>`;
        menu.appendChild(helloDiv);
      }

      // Create a Workshop - only if the user is login
      const createBtn = document.getElementById("createWorkshopBtn");
      if (createBtn) {
        createBtn.addEventListener("click", function (e) {
          if (!data.loggedIn) {
            e.preventDefault();
            alert("You must be login first! ✋");
            window.location.href = "/HTML/Login.html";
          }
        });
      }
    });
});
